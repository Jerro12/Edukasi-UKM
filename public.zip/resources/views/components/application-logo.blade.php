<div class="">
    <h1 class="text-xl font-bold  text-pink-600">EDKAS-UKM</h1>
</div>
