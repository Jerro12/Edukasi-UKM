<div class="">
    <h1 class="text-xl font-bold  text-pink-600">EDKAS-UKM</h1>
</div>
<?php /**PATH D:\laragon\www\edukasi-ukm\resources\views/components/application-logo.blade.php ENDPATH**/ ?>