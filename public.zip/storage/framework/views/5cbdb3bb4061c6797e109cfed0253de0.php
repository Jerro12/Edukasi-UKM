
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-pink-50 min-h-screen">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-pink-600">

                <h1 class="text-2xl font-bold text-pink-800 mb-4">
                    <?php echo e($template->title); ?>

                </h1>

                
                <p class="text-gray-700 mb-4">
                    <?php echo e($template->description ?? 'Tidak ada deskripsi.'); ?>

                </p>

                
                <?php if($template->example_link): ?>
                    <div class="mb-4">
                        <a href="<?php echo e($template->example_link); ?>" target="_blank"
                            class="inline-flex items-center px-3 py-1 text-sm border rounded-md text-pink-700 border-pink-300 hover:bg-pink-50 transition">
                            🔗 Lihat di Canva
                        </a>
                    </div>
                <?php endif; ?>

                
                <?php if(!empty($fileUrl)): ?>
                    <div class="mb-4">
                        <p class="font-semibold mb-2">File Desain:</p>

                        <?php
                            $ext = pathinfo($template->file_path, PATHINFO_EXTENSION);
                        ?>

                        
                        <?php if(in_array(strtolower($ext), ['png', 'jpg', 'jpeg', 'svg'])): ?>
                            <img src="<?php echo e($fileUrl); ?>" alt="Preview Desain" class="max-w-md rounded shadow">
                        <?php else: ?>
                            <a href="<?php echo e($fileUrl); ?>" target="_blank"
                                class="inline-flex items-center px-3 py-1 text-sm border rounded-md text-blue-700 border-blue-300 hover:bg-blue-50 transition">
                                📂 Download File
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                <div class="flex items-center gap-3 mt-6">
                    <a href="<?php echo e(route('supplier.templates.index')); ?>"
                        class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md">
                        ← Kembali
                    </a>

                    <a href="<?php echo e(route('supplier.templates.edit', $template->id)); ?>"
                        class="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-md">
                        ✏️ Edit
                    </a>

                    
                    <form method="POST" action="<?php echo e(route('supplier.templates.destroy', $template->id)); ?>"
                        onsubmit="return confirm('Yakin ingin menghapus template ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-md">
                            🗑️ Hapus
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\edukasi-ukm\resources\views/supplier/show.blade.php ENDPATH**/ ?>