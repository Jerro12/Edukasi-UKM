<?php

namespace App\Filament\Resources\BabMateriResource\Pages;

use App\Filament\Resources\BabMateriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBabMateri extends CreateRecord
{
    protected static string $resource = BabMateriResource::class;
}
