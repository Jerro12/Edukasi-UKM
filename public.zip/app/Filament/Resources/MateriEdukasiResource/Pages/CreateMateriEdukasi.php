<?php

namespace App\Filament\Resources\MateriEdukasiResource\Pages;

use App\Filament\Resources\MateriEdukasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMateriEdukasi extends CreateRecord
{
    protected static string $resource = MateriEdukasiResource::class;
}
